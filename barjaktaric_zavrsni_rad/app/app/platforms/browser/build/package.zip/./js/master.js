$(function(){

$('.form-wrapper a').on('click', function() {
  $(this).addClass('hide');
  $('#post-form').addClass('show').removeClass('hide');
});


});
